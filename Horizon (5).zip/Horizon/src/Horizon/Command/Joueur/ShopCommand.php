<?php

namespace Horizon\Command\Joueur;

use Horizon\API\CoinAPI;
use Horizon\Core;
use Horizon\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\item\Item;
use pocketmine\item\ItemIds;
use pocketmine\Player;

class ShopCommand extends Command{
    public static $prix = [];
    public static $nam = [];
    public static $id = [];
    public static $count = [];
    public function __construct(){
        parent::__construct("shop", "Permet d'acheter des items");
    }
    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if($sender instanceof Player){
            $this->ShopForm($sender);
        }
    }

    public function ShopForm($player){
        $api = Core::getInstance()->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $p, int $data = null){
            switch ($data){
                case 1:
                    self::EquipementForm($p);
                    break;
                case 2:
                    self::ItemForm($p);
            }
        });
        $form->setTitle("§l§6» §r§eHorizon §fShop");
        $form->setContent("Tu as §6" . CoinAPI::getMoney($player) . "T");
        $form->addButton("§c<- Fermer");
        $form->addButton("§l§e» §r§fEquipement");
        $form->addButton("§l§e» §r§fItems");
        $form->sendToPlayer($player);
    }
    public static function ItemForm($player){
        $api = Core::getInstance()->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $p, int $data = null){
            switch ($data){
                case 1:
                    self::AchatForm($p, "Arc", 75, ItemIds::BOW, 1);
                    break;
                case 2:
                    self::AchatForm($p, "64 x Fleches", 20, ItemIds::ARROW, 64);
                    break;
                case 3:
                    self::AchatForm($p, "Gapple", 5, ItemIds::GOLDEN_APPLE, 1);
                    break;
                case 4:
                    self::AchatForm($p, "16 x Snowball", 15, ItemIds::SNOWBALL, 16);
                    break;
                case 5:
                    self::AchatForm($p, "Potion launcher", 100, 422, 1);
                    break;
            }
        });
        $form->setTitle("§l§6§» §r§eHorizon fShop");
        $form->setContent("Tu as §6" . CoinAPI::getMoney($player) . "T");
        $form->addButton("§l» §r§fArc - §e75T", 0, "textures/items/bow_standby");
        $form->addButton("§l» §r§f64 x Flèches - §e20T", 0, "textures/items/arrow");
        $form->addButton("§l» §r§fGapple - §e5T", 0, "textures/items/apple_gold");
        $form->addButton("§l» §r§f16 x Snowball - §e15T", 0, "textures/items/snowball");
        $form->addButton("§l» §r§fEnderpearl - §e50T", 0, "textures/items/ender_pearl");
        $form->addButton("§l» §r§fPotion launcher - §e100T");
        $form->sendToPlayer($player);
    }
    public static function EquipementForm($player){
        $api = Core::getInstance()->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $p, int $data = null){
            switch ($data){
                case 1:
                    self::ArmuresForm($p);
                    break;
                case 2:
                    self::EpeeForm($p);
                    break;
            }
        });
        $form->setTitle("§l§6» §r§eHorizon §fShop");
        $form->setContent("Tu as §6" . CoinAPI::getMoney($player) . "T");
        $form->addButton("§c<- Fermer");
        $form->addButton("§l» §r§fArmures");
        $form->addButton("§l» §r§fEpée");
        $form->sendToPlayer($player);
    }
    public static function EpeeForm($player){
        $api = Core::getInstance()->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $p, int $data = null){
            switch ($data){
                case 1:
                    self::AchatForm($p, "Epee en Netherite", 400, ItemIds::WOODEN_SWORD, 1);
                    break;
                case 2:
                    self::AchatForm($p, "Epee en Horizone", 900, ItemIds::WOODEN_AXE, 1);
                    break;
            }
        });
        $form->setTitle("§l§6» §r§eHorizon §fShop");
        $form->setContent("Tu as §6" . CoinAPI::getMoney($player) . "T");
        $form->addButton("§c<- Fermer");
        $form->addButton("§l» §r§fEpée en Netherite - §e400T", 0, "textures/items/netherite_sword");
        $form->addButton("§l» §r§fEpée en Horizone - §e900T", 0, "textures/items/gold_sword");
        $form->sendToPlayer($player);
    }
    public static function ArmuresForm($player){
        $api = Core::getInstance()->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $p, int $data = null){
            switch ($data){
                case 1:
                    self::NetheriteForm($p);
                    break;
                case 2:
                    self::HorizoneForm($p);
                    break;
            }
        });
        $form->setTitle("§l§6» §r§eHorizon §fShop");
        $form->setContent("Tu as §6" . CoinAPI::getMoney($player) . "T");
        $form->addButton("§c<- Fermer");
        $form->addButton("§l» §r§fArmure en Netherite", 0, "textures/items/netherite_chestplate");
        $form->addButton("§l» §r§fArmure en Horizone", 0, "textures/items/gold_chestplate");
        $form->sendToPlayer($player);
    }
    public static function NetheriteForm($player){
        $api = Core::getInstance()->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $p, int $data = null){
            switch ($data){
                case 1:
                    self::AchatForm($p, "Casque en Netherite", 750, 748, 1);
                    break;
                case 2:
                    self::AchatForm($p, "Plastron en Netherite", 750, 749, 1);
                    break;
                case 3:
                    self::AchatForm($p, "Jambière en Netherite", 750, 750, 1);
                    break;
                case 4:
                    self::AchatForm($p, "Bottes en Netherite", 750, 751, 1);
                    break;
            }
        });
        $form->setTitle("§l§6» §r§eHorizon §fShop");
        $form->setContent("Tu as §6" . CoinAPI::getMoney($player) . "T");
        $form->addButton("§c<- Fermer");
        $form->addButton("§l» §r§fCasque   - §e750T", 0, "textures/items/netherite_helmet");
        $form->addButton("§l» §r§fPlastron - §e850T", 0, "textures/items/netherite_chestplate");
        $form->addButton("§l» §r§fJambière - §e850T", 0, "textures/items/netherite_leggings");
        $form->addButton("§l» §r§fBottes   - §e750T", 0, "textures/items/netherite_boots");
        $form->sendToPlayer($player);
    }
    public static function HorizoneForm($player){
        $api = Core::getInstance()->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $p, int $data = null){
            switch ($data){
                case 1:
                    self::AchatForm($p, "Casque en Horizone", 200, ItemIds::CHAIN_HELMET, 1);
                    break;
                case 2:
                    self::AchatForm($p, "Plastron en Horizone", 300, ItemIds::CHAIN_CHESTPLATE, 1);
                    break;
                case 3:
                    self::AchatForm($p, "Jambière en Horizone", 300, ItemIds::CHAIN_LEGGINGS, 1);
                    break;
                case 4:
                    self::AchatForm($p, "Bottes en Horizone", 200, ItemIds::CHAIN_BOOTS, 1);
                    break;
            }
        });
        $form->setTitle("§l§6» §r§eHorizon §fShop");
        $form->setContent("Tu as §6" . CoinAPI::getMoney($player) . "T");
        $form->addButton("§c<- Fermer");
        $form->addButton("§l» §r§fCasque   - §e200T", 0, "textures/items/gold_helmet");
        $form->addButton("§l» §r§fPlastron - §e300T", 0, "textures/items/gold_chestplate");
        $form->addButton("§l»§r §fJambière - §e200T", 0, "textures/items/gold_leggings");
        $form->addButton("§l» §r§fBottes   - §e300T", 0, "textures/items/gold_boots");
        $form->sendToPlayer($player);
    }

    public static function AchatForm($player, $name, int $prix, int $id, int $count){
        self::$prix[$player->getName()] = $prix;
        self::$nam[$player->getName()] = $name;
        self::$id[$player->getName()] = $id;
        self::$count[$player->getName()] = $count;
        $api = Core::getInstance()->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $p, int $data = null){
            switch ($data){
                case 0:
                    self::$prix[$p->getName()] = 0;
                    self::$nam[$p->getName()] = 0;
                    self::$id[$p->getName()] = 0;
                    self::$count[$p->getName()] = 0;
                    break;
                case 1:
                    if(CoinAPI::getMoney($p) >= self::$prix[$p->getName()]){
                        CoinAPI::removeMoney($p, self::$prix[$p->getName()]);
                        $p->sendMessage(Utils::getPrefix() . "Tu as bien acheté §6". self::$nam[$p->getName()]);
                        $p->getInventory()->addItem(Item::get(self::$id[$p->getName()], 0, self::$count[$p->getName()]));
                    }else{
                        $p->sendMessage(Utils::getPrefix() . "§cTu n'as pas assez d'argent !");
                    }
                    break;
            }
            return true;
        });
        $form->setTitle("§l§6» §eHorizon §fShop");
        $form->setContent("§7Tu as §6" . CoinAPI::getMoney($player) . "§f de money \n§fTu confirme ton achat ?\n§fAchat : $name");
        $form->addButton("§l§e» §r§cNon");
        $form->addButton("§l§e» §r§aOui");
        $form->sendToPlayer($player);
    }
}