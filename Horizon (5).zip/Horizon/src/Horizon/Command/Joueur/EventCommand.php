<?php

namespace Horizon\Command\Joueur;

use Horizon\API\RankAPI;
use Horizon\Core;
use Horizon\Task\Event\JumpTask;
use Horizon\Task\EventTask;
use Horizon\Utils\Permissions;
use Horizon\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Event;
use pocketmine\level\Position;
use pocketmine\Player;

class EventCommand extends Command{
    public function __construct(){
        parent::__construct("event", "Permet de se téléporter à l'évent");
    }
    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if($sender instanceof Player) {
            if (EventTask::$event == "rien") {
                $sender->sendMessage(Utils::EVENT . "§cIl n'y a pas d'event pour le moment");
            } else {
                switch (EventTask::$event) {
                    case "jump":
                        $sender->sendMessage(Utils::EVENT . "Tu as bien été téléporté à l'event");
                        $sender->teleport(Core::getInstance()->getServer()->getLevelByName("event")->getSafeSpawn());
                        JumpTask::$pl = "on";
                        break;
                }
            }
            if(RankAPI::hasPerm($sender, Permissions::EVENT)){
                if(isset($args[0])){
                    switch ($args[0]){
                        case "jump":
                            Core::getInstance()->getServer()->broadcastMessage(Utils::EVENT . "Event jump ! Téléportez vous avec le /event");
                            Core::getInstance()->getScheduler()->scheduleRepeatingTask(new JumpTask(), 20);
                            EventTask::$event = "jump";
                            break;
                    }
                }
            };
        }
    }
}