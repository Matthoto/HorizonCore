<?php

namespace Horizon\Command\Joueur;

use Horizon\Core;
use Horizon\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;

class SpawnCommand extends Command{
    public function __construct()
    {
        parent::__construct("spawn", "Permet de se téléporté au spawn", "/spawn", ["hub", "lobby"]);
    }
    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if($sender instanceof Player){
            $sender->teleport(Core::getInstance()->getServer()->getDefaultLevel()->getSafeSpawn());
            $sender->sendMessage(Utils::getPrefix() . "Tu viens d'être téléporté au spawn");
        }
    }
}