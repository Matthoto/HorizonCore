<?php

namespace Horizon\Command\Joueur;

use Horizon\API\PassCombatAPI;
use Horizon\Core;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;

class PassDeCombatCommand extends Command{
    public function __construct()
    {
        parent::__construct("passdecombat", "Permet de voir son niveau sur le pass de combat", "Usage : /passdecombat [player]", ["pc", "passcombat", "pass"]);
    }
    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if($sender instanceof Player){
            $this->PassForm($sender);
        }
    }
    public function PassForm($player){
        $api = Core::getInstance()->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $p, int $data = null){
            $r = $data;
            switch ($r){
                case 1:
                    $this->TonGrade($p);
                    break;
                case 2:
                    $this->XpForm($p);
            }
        });
        $form->setTitle("§l§6» §eHorizon §fPass de combat");
        $form->setContent("Choisi une option");
        $form->addButton("§c<- Retour");
        $form->addButton("§l» §rTon grade");
        $form->addButton("§l» §rComment xp");
        $form->sendToPlayer($player);
    }
    public function TonGrade($player){
        $api = Core::getInstance()->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $p, $data){
            $r = $data;
            switch ($r){
                case 0:
                    $this->PassForm($p);
                    break;
                case 1:
                    break;
            }
        });
        $form->setTitle("§l§6» §eHorizon §fPass de combat");
        $form->setContent("§7Tu es: §6§l" . PassCombatAPI::FormatPalier($player) . "§r \n§7Il y a comme niveau: \n §6§lBronze (100 xp/level): \n §6Bronze I: 100€ \n §6Bronze II: 200€ \n §6Bronze III: 2 key Vote \n\n §fArgent: (200 xp/level) \n§fArgent I: 300€\n§fArgent II: 300€\n§fArgent III: 2 key Vote\n\n§eOr: (300 xp/level) \n§eOr I: 600€\n§eOr II: 1 key Epique\n§eOr III: 650€\n\n §bDiamant: (400 xp/level) \n§bDiamant I: 600€\n§bDiamant II: 2 key Epique\n§bDiamant III: 650€\n\n§aEmeraude (500 xp/level): \n§aEmeraude I: 700€\n§aEmeraude II: 3 key Epique\n§aEmeraude I: 800€\n\n§5Epique: (750 xp/level)\n§5Epique I: 4 key Epique\n§5Epique II: 1 key Horizone\n§5Epique III: 5 key Epique et 2 key Horizone");
        $form->addButton("§c<- Retour");
        $form->addButton("§l§4» §r§cFermé");
        $form->sendToPlayer($player);
    }
    public function XpForm($player){
        $api = Core::getInstance()->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $p, $data){
            $r = $data;
            switch ($r){
                case 0:
                    $this->PassForm($p);
                    break;
                case 1:
                    break;
            }
        });
        $form->setTitle("§l§6» §r§eHorizon §fPass de combat");
        $form->setContent("§fTu es a " . PassCombatAPI::ScoreBoardXP($player) . " \n\n§fComment xp ?\n§a20 xp par kill\n§c-10 xp par mort");
        $form->addButton("§c<- Retour");
        $form->addButton("§l§4» §r§cFermé");
        $form->sendToPlayer($player);
    }
}