<?php

namespace Horizon\Command\Joueur;

use Horizon\API\CoinAPI;
use Horizon\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;

class MoneyCommand extends Command{
    public function __construct(){
        parent::__construct("money", "Permet de voir son argent", "/money [player]", ["mymoney", "coin", "mycoin", "jetons", "myjetons"]);
    }
    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if($sender instanceof Player){
            $j = CoinAPI::getMoney($sender);
            $sender->sendMessage(Utils::getPrefix() . "Tu as §6{$j} §fcoin(s)");
        }
    }
}