<?php

namespace Horizon\Command\Joueur;

use Horizon\API\RankAPI;
use Horizon\Core;
use Horizon\Utils\Permissions;
use Horizon\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use Horizon\API\KitAPI;

class KitCommand extends Command{
    public function __construct()
    {
        parent::__construct("kit", "Permet de reçevoir un kit");
    }
    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if($sender instanceof Player){
            $this->KitForm($sender);
        }
    }
    public function KitForm($player){
        $api = Core::getInstance()->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $p, int $data = null){
            $r = $data;
            if($r == null){
                return true;
            }
            switch ($r){
                case 1:
                    KitAPI::addKitJoueur($p);
                    break;
                case 2:
                    KitAPI::addKitHeal($p);
                    break;
                case 3:
                    if(!RankAPI::hasPerm($p, Permissions::Vip)) return $p->sendMessage(Utils::NOPERM);
                    KitAPI::addKitVIP($p);
                    break;
                case 4:
                    if(!RankAPI::hasPerm($p, Permissions::VipPlus)) return $p->sendMessage(Utils::NOPERM);
                    KitAPI::addKitVIPPlus($p);
                    break;
                case 5:
                    if(!RankAPI::hasPerm($p, Permissions::Divin)) return $p->sendMessage(Utils::NOPERM);
                    KitAPI::addKitHero($p);
                    break;
                case 6:
                    if(!RankAPI::hasPerm($p, Permissions::Legende)) return $p->sendMessage(Utils::NOPERM);
                    KitAPI::addKitChampion($p);
                    break;
                case 7:
                    KitAPI::addKitTools($p);
                    break;
            }
            return true;
        });
        $form->setTitle("§l§6» §eHorizon §fKits");
        $form->addButton("§c<- Retour");
        $form->addButton("§l» §r§7Joueur");
        $form->addButton("§l» §r§7Potion");
        $form->addButton("§l» §r§eVIP");
        $form->addButton("§l» §r§6VipPlus");
        $form->addButton("§l» §r§9Divin");
        $form->addButton("§l» §r§5Légende");
        $form->addButton("§l» §r§7Tools");
        $form->sendToPlayer($player);
    }
}