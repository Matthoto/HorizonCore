<?php

namespace Horizon\Command\Joueur;

use Horizon\API\CoinAPI;
use Horizon\Core;
use Horizon\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;

class PayCommand extends Command{
    public function __construct(){
        parent::__construct("pay", "Permet de payer quelqu'un", "/pay [player] (amount)", ["sendmoney", "sendcoin", "paycoin", "sendjetons", "payjetons"]);
    }
    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if($sender instanceof Player){
            $j = CoinAPI::getMoney($sender);
            if(count($args) < 2) return $sender->sendMessage(Utils::getPrefix() . "Usage : /pay (player) [amount]");
            $p = Core::getInstance()->getServer()->getPlayer($args[0]);
            if($p == null) return $sender->sendMessage(Utils::getPrefix() . "Le joueur n'est pas connecté");
            CoinAPI::removeMoney($sender, $args[1]);
            CoinAPI::addMoney($p, $args[1]);
            $sender->sendMessage(Utils::getPrefix() . "Tu as bien envoyé §6{$args[1]}€ §fà §6{$p->getName()}");
            $p->sendMessage(Utils::getPrefix() . "Tu as reçu §6{$args[1]}€ §fde la part de §6{$sender->getName()}");
        }
        return true;
    }
}