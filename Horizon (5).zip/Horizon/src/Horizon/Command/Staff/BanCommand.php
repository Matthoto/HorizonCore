<?php

namespace Horizon\Command\Staff;

use Horizon\API\RankAPI;
use Horizon\Core;
use Horizon\Utils\Permissions;
use Horizon\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\Config;

class BanCommand extends Command{
    /** @var Config */
    public static $list;
    public function __construct(){
        parent::__construct("ban", "Permet de bannir un joueur");
    }
    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if($sender instanceof Player) {
            if (!RankAPI::hasPerm($sender, Permissions::BAN)) return $sender->sendMessage(Utils::NOPERM);
            if(count($args) < 1) return $sender->sendMessage(Utils::getPrefix() . "Usage: /ban (player) (time)");
            $p = Core::getInstance()->getServer()->getPlayer($args[0]);
            if($p == null) return $sender->sendMessage(Utils::getPrefix() . "§cLe joueur n'est pas connecté");
            if($args[1] == "-1") $t = "on"; else $t = $args[1] * 84600 + time();
            self::$list->set($p->getName(), "{$sender->getName()}:{$t}");
            self::$list->save();
            $p->kick("§e----- [ §6Horizon-Sanction §e] ----- \n §eTu as été banni(e) par : §f{$sender->getName()} \n §ePendant encore : §f{$args[1]} jour(s) \n §e----- [ §6Horizon-Sanction §e] -----", false);
            Core::getInstance()->getServer()->broadcastMessage(Utils::SANC . "§6{$p->getName()} §fa été banni(e) par §6{$sender->getName()} §fpour  §6{$r} §fpendant §6{$args[1]} §fjour(s)");
        }
        return true;
    }
}
