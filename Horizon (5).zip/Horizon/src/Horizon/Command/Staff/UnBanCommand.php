<?php

namespace Horizon\Command\Staff;

use Horizon\API\RankAPI;
use Horizon\Core;
use Horizon\Utils\Permissions;
use Horizon\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;

class UnBanCommand extends Command{
    public function __construct(){
        parent::__construct("unban", "Permet de débannir un joueur");
    }
    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if($sender instanceof Player) {
            if (!RankAPI::hasPerm($sender, Permissions::BAN)) return $sender->sendMessage(Utils::NOPERM);
            if(count($args) < 1) return $sender->sendMessage(Utils::getPrefix() . "Usage: /ban (player) (time) [raison]");
            if($args[0] == null) return $sender->sendMessage(Utils::getPrefix() . "§cLe joueur n'est pas connecté");
            BanCommand::$list->set($args[0], "off");
            BanCommand::$list->save();
            Core::getInstance()->getServer()->broadcastMessage(Utils::SANC . "§6{$args[0]} §fa été débanni par §6{$sender->getName()}");
        }
        return true;
    }
}
