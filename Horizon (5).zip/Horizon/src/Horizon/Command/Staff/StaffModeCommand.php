<?php

namespace Horizon\Command\Staff;

use Horizon\API\RankAPI;
use Horizon\Utils\Permissions;
use Horizon\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;

class StaffModeCommand extends Command{
    public static $db = [];
    public static $inv = [];
    public function __construct(){
        parent::__construct("staffmode", "Permet de spec les joueurs");
    }
    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if($sender instanceof Player){
            if(!RankAPI::hasPerm($sender, Permissions::STAFFMODE)) return $sender->sendMessage(Utils::NOPERM);
            $pinfo = self::$db[$sender->getName()] ?? "non";
            if($pinfo == "off") {
                $sender->setInvisible(true);
                self::$inv[$sender->getName()] = $sender->getInventory()->getContents();
                $sender->getInventory()->clearAll();
                $sender->sendMessage(Utils::getPrefix() . "Vous êtes en staffmode");
            }else{
                $sender->setInvisible(false);
                $sender->getInventory()->clearAll();
                $sender->getInventory()->setContents(self::$inv[$sender->getName()]);
                $sender->sendMessage(Utils::getPrefix() . "Vous n'êtes plus en staffmode");
            }
        }
        return true;
    }
}