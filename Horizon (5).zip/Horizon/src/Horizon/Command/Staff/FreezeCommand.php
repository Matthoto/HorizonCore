<?php

namespace Horizon\Command\Staff;

use Horizon\API\RankAPI;
use Horizon\Core;
use Horizon\Utils\Permissions;
use Horizon\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\Config;

class FreezeCommand extends Command{
    /** @var Config */
    public static $list;
    public function __construct()
    {
        parent::__construct("freeze", "Permet d'immobiliser un joueur");
    }
    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if($sender instanceof Player){
            if(!RankAPI::hasPerm($sender, Permissions::FREEZE)) return $sender->sendMessage(Utils::NOPERM);
            if(!isset($args)) return $sender->sendMessage(Utils::getPrefix() . "Usage : /freeze (player)");
            $p = Core::getInstance()->getServer()->getPlayer($args[0]);
            if($p == null) return $sender->sendMessage(Utils::getPrefix() . "§cLe joueur n'est pas connecté");

            if(self::$list->get($p->getName()) == "on"){
                self::$list->set($p->getName(), "off");
                Core::getInstance()->getServer()->broadcastMessage(Utils::SANC . "§6{$p->getName()} §fn'est plus immobilisé par §6{$sender->getName()}");
                $p->setImmobile(false);
            }else {
                $p->teleport(Core::getInstance()->getServer()->getDefaultLevel()->getSafeSpawn());
                $p->setImmobile(true);
                $p->sendMessage(Utils::getPrefix() . "Tu as été immobilisé par §6{$sender->getName()}");
                Core::getInstance()->getServer()->broadcastMessage(Utils::SANC . "§6{$p->getName()} §fa été immobilisé par §6{$sender->getName()}");
                self::$list->set($p->getName(), "on");
            }
            self::$list->save();
        }
    }
}