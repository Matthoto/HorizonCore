<?php

namespace Horizon\Command\Staff;

use Horizon\API\RankAPI;
use Horizon\Core;
use Horizon\Utils\Permissions;
use Horizon\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\Config;

class MuteCommand extends Command{
    /** @var Config */
    public static $mute;
    public function __construct(){
        parent::__construct("mute", "Permet d'expulser un joueur");
    }
    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if($sender instanceof Player) {
            if (!RankAPI::hasPerm($sender, Permissions::MUTE)) return $sender->sendMessage(Utils::NOPERM);
            if(count($args) < 3) return $sender->sendMessage(Utils::getPrefix() . "Usage: /mute (player) [time] [raison]");
            $p = Core::getInstance()->getServer()->getPlayer($args[0]);
            if($p == null) return $sender->sendMessage(Utils::getPrefix() . "§cLe joueur n'est pas connecté");
            if(self::$mute->exists($sender->getName())) {
                $l = explode(":", self::$mute->get($sender->getName()));
                if ($l[0] > time()) {
                    self::$mute->set($p->getName(), "0:{$sender->getName()}:Aucune:Demute");
                    self::$mute->save();
                    Core::getInstance()->getServer()->broadcastMessage(Utils::SANC . "§6{$p->getName()}§f a été demute par §6{$sender->getName()}");
                    return true;
                }else {
                    $t = $args[1] * 60 + time();
                    $m = [];
                    for ($i = 2; $i < count($args); $i++) {
                        array_push($m, $args[$i]);
                    }
                    $m = implode(" ", $m);
                    self::$mute->set($p->getName(), "{$t}:{$sender->getName()}:{$m}");
                    self::$mute->save();
                    Core::getInstance()->getServer()->broadcastMessage(Utils::SANC . "§6{$p->getName()}§f a été mute par §6{$sender->getName()} §fpendant §6{$t} §fpour §6{$m}");
                }
            }else {
                $t = $args[1] * 60 + time();
                $m = [];
                for ($i = 1; $i < count($args); $i++) {
                    array_push($m, $args[$i]);
                }
                $m = implode(" ", $m);
                self::$mute->set($p->getName(), "{$t}:{$sender->getName()}:{$m}");
                self::$mute->save();
                Core::getInstance()->getServer()->broadcastMessage(Utils::SANC . "§6{$p->getName()}§f a été mute par §6{$sender->getName()} §fpendant §6{$t} §fpour §6{$m}");
            }
        }
        return true;
    }
}