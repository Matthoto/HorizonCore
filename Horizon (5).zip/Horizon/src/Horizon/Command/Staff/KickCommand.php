<?php

namespace Horizon\Command\Staff;

use Horizon\API\RankAPI;
use Horizon\Core;
use Horizon\Utils\Permissions;
use Horizon\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;

class KickCommand extends Command{
    public function __construct(){
        parent::__construct("kick", "Permet d'expulser un joueur");
    }
    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if($sender instanceof Player) {
            if (!RankAPI::hasPerm($sender, Permissions::KICK)) return $sender->sendMessage(Utils::NOPERM);
            if(count($args) < 2) return $sender->sendMessage(Utils::getPrefix() . "Usage: /kick (player) [raison]");
            $p = Core::getInstance()->getServer()->getPlayer($args[0]);
            if($p == null) return $sender->sendMessage(Utils::getPrefix() . "§cLe joueur n'est pas connecté");
            $m = [];
            for ($i = 1; $i < count($args); $i++) {
                array_push($m, $args[$i]);
            }
            $m = implode(" ", $m);
            $p->kick("§e----- [ §6Horizon-Sanction §e] ----- \n §eTu as été expulsé par : §f{$sender->getName()} \n §Pour : §f[$m} \n §e----- [ §6Horizon-Sanction §e] -----", false);
            Core::getInstance()->getServer()->broadcastMessage(Utils::SANC . "§6{$p->getName()} §fa été expulsé par §6{$sender->getName()} §fpour : §6{$a}");
        }
        return true;
    }
}