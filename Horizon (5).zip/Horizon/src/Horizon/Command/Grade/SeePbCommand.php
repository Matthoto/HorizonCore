<?php

namespace Horizon\Command\Grade;

use Horizon\API\PointBoutiqueAPI;
use Horizon\Core;
use Horizon\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;

class SeePbCommand extends Command{
    public function __construct(){
        parent::__construct("seegm", "Permet de voir les pb de quelqu'un");
    }
    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if($sender instanceof Player){
            if(!isset($args[0])) return $sender->sendMessage(Utils::getPrefix() . "§cMerci de précisez un joueur");
            $p = Core::getInstance()->getServer()->getPlayer($args[0]);
            if(!isset($p)) return $sender->sendMessage(Utils::getPrefix() . "§cMerci de précisez un joueur connecté");
            $r = PointBoutiqueAPI::getPB($p);
            $sender->sendMessage(Utils::getPrefix() . "§e{$p->getName()} §fpossède §e$r §fpoint(s) boutique(s)");
        }
        return true;
    }
}