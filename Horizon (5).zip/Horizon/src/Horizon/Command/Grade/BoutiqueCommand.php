<?php

namespace Horizon\Command\Grade;

use Horizon\Utils\BoutiqueForm;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;

class BoutiqueCommand extends Command{
    public function __construct(){
        parent::__construct("boutique", "Permet d'acheter des trucs avec les pb");
    }
    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if($sender instanceof Player){
            BoutiqueForm::Menu($sender);
        }
    }
}