<?php

namespace Horizon\Command\Grade;

use Horizon\API\PointBoutiqueAPI;
use Horizon\Core;
use Horizon\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;

class PayPbCommand extends Command
{
    public function __construct()
    {
        parent::__construct("paygm", "Permet de payer quelqu'un en pb");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if ($sender instanceof Player) {
            if (count($args) < 1) return $sender->sendMessage(Utils::getPrefix() . "Usage : /paygm <player> <amount>");
            $p = Core::getInstance()->getServer()->getPlayer($args[0]);
            if (!isset($p)) return $sender->sendMessage(Utils::getPrefix() . "§cCe joueur n'est pas connecté");
            if (!is_numeric($args[1])) return $sender->sendMessage(Utils::getPrefix() . "§cMerci de mettre une somme valide");
            if ($args[1] < 0) return $sender->sendMessage(Utils::getPrefix() . "§cTu ne peux pas donné moins de 0 PB");
            if ($args[1] > PointBoutiqueAPI::getPB($sender)) return $sender->sendMessage(Utils::getPrefix() . "§cTu n'as pas assez de pb");
            PointBoutiqueAPI::addPB($p, $args[1]);
            $p->sendMessage(Utils::getPrefix() . "Tu as reçu §e{$args[1]} §fde la part de §e{$sender->getName()}");
            PointBoutiqueAPI::removePB($sender, $args[1]);
            $sender->sendMessage(Utils::getPrefix() . "Tu as envoyé §e{$args[1]} §fà §e{$p->getName()}");
        }
    }
}