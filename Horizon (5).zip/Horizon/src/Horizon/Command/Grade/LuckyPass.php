<?php

namespace Horizon\Command\Grade;

use Horizon\API\RankAPI;
use Horizon\Core;
use Horizon\Utils\Permissions;
use Horizon\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\utils\Config;

class LuckyPass extends Command{
    /** @var Config */
    public static $list;
    public function __construct(){
        parent::__construct("luckypass", "Permet d'obtenir des lucky block");
    }
    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if($sender instanceof Player){
            $this->LuckyForm($sender);
        }
    }
    public function LuckyForm($player){
        $api = Core::getInstance()->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $p, int $data = null){
            $r = $data;
            switch ($r){
                case 1:
                    if(!RankAPI::hasPerm($p, Permissions::Lucky)) return $p->sendMessage(Utils::getPrefix() . "Tu aimerai obtenir ce lucky pass ? Achète un grade sur notre boutique");
                    $d = date("d");
                    if(self::$list->exists($p->getName())){
                        if(self::$list->get($p->getName()) != $d){
                            self::$list->set($p->getName(), $d);
                            $r = random_int(1, 3);
                            Core::getInstance()->getServer()->broadcastMessage(Utils::LUCKY . "§6{$p->getName()} §fviens de gagner {$r} lucky block");
                            $i = Item::get(19, 0, $r);
                            $i->setCustomName("§eLucky Block");
                            $p->getInventory()->addItem($i);
                        }
                    }else{
                        self::$list->set($p->getName(), $d);
                        $r = random_int(1, 3);
                        Core::getInstance()->getServer()->broadcastMessage(Utils::LUCKY . "§6{$p->getName()} §fviens de gagner {$r} lucky block");
                        $i = Item::get(19, 0, $r);
                        $i->setCustomName("§eLucky Block");
                        $p->getInventory()->addItem($i);
                    }
                    self::$list->save();
            }
            return true;
        });
        $form->setTitle("§l» §r§eLucky Pass");
        $form->setContent("§fSalut ! Veut-tu tenter ta chance ?");
        $form->addButton("§c<- Retour");
        $form->addButton("§l» §r§aTournez la roue");
        $form->sendToPlayer($player);
    }
}