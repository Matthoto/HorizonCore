<?php

namespace Horizon\Command\Grade;

use Horizon\API\PointBoutiqueAPI;
use Horizon\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;

class MyPbCommand extends Command{
    public function __construct(){
        parent::__construct("mygm", "Permet de voir ses pb");
    }
    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if($sender instanceof Player){
            $r = PointBoutiqueAPI::getPB($sender);
            $sender->sendMessage(Utils::getPrefix() . "Vous avez : §e$r §fpoint(s) boutique(s)");
        }
    }
}