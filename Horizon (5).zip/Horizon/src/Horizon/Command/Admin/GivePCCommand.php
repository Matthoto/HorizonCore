<?php

namespace Horizon\Command\Admin;

use Horizon\API\PassCombatAPI;
use Horizon\API\RankAPI;
use Horizon\Core;
use Horizon\Utils\Permissions;
use Horizon\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;

class GivePCCommand extends Command{
    public function __construct(){
        parent::__construct("givepc", "Permet de se give de l'xp dans son pass de combat");
    }
    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if($sender instanceof Player){
            if(!RankAPI::hasPerm($sender, Permissions::PASSCOMBAT)) return $sender->sendMessage(Utils::NOPERM);
            if(count($args) < 1) return $sender->sendMessage(Utils::getPrefix() . "Usage : <player> [amount]");
            $p = Core::getInstance()->getServer()->getPlayer($args[0]);
            if($p == null) return $sender->sendMessage(Utils::getPrefix() . "§cMerci de mettre un joueur connecté");
            PassCombatAPI::addXp($p, $args[1]);
            $sender->sendMessage(Utils::getPrefix() . "§cTu as bien ajouté {$args[1]} xp(s) à {$p->getName()}");
        }
    }
}