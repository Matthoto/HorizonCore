<?php

namespace Horizon\Command\Admin;

use Horizon\API\CoinAPI;
use Horizon\API\RankAPI;
use Horizon\Core;
use Horizon\Utils\Permissions;
use Horizon\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;

class SetMoneyCommand extends Command{
    public function __construct(){
        parent::__construct("setmoney", "Permet de set l'argent a quelqu'un", "/setmoney <player>");
    }
    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if($sender instanceof Player){
            if(!RankAPI::hasPerm($sender, Permissions::SETMONEY)) return $sender->sendMessage(Utils::NOPERM);
            if(count($args) < 2) return $sender->sendMessage(Utils::getPrefix() . "Usage : /pay (player) [amount]");
            $p = Core::getInstance()->getServer()->getPlayer($args[0]);
            if($p == null) return $sender->sendMessage(Utils::getPrefix() . "Le joueur n'est pas connecté");
            CoinAPI::addMoney($p, $args[1]);
            $p->sendMessage(Utils::getPrefix() . "Tu as reçu un cadeau de la part d'un staff ! Tu as reçu §6{$args[1]} §fd'argent !");
        }
        return true;
    }
}