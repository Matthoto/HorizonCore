<?php

namespace Horizon\Command\Admin;

use Horizon\API\RankAPI;
use Horizon\Core;
use Horizon\Utils\Permissions;
use Horizon\Utils\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;

class SetRankCommand extends Command{
    public function __construct(){
        parent::__construct("setrank", "Permet de set un rank a quelqu'un");
    }
    public function execute(CommandSender $sender, string $commandLabel, array $args)
    {
        if($sender instanceof Player) {
            if (!RankAPI::hasPerm($sender, Permissions::RANK)) return $sender->sendMessage(Utils::NOPERM);
            if(count($args) < 2) return $sender->sendMessage(Utils::getPrefix() . "Usage : /setrank <player> <rank>");
            $p = Core::getInstance()->getServer()->getPlayer($args[0]);
            $r = $args[1];
            $t = RankAPI::setRank($p, $r);
            if($t){
                $sender->sendMessage(Utils::getPrefix() . "Tu as bien mis le rank de §6{$p->getName()} §fsur §e$r !");
                $p->sendMessage(Utils::getPrefix() . "Tu as reçu le rank §e$r");
            }else{
                $sender->sendMessage(Utils::getPrefix() . "Impossible de mettre le rank §e{$r}§f à §6{$p->getName()} §f, rank inexistant ou corrompu !");
            }
        }else{
            if(count($args) < 2) return $sender->sendMessage(Utils::getPrefix() . "Usage : /setrank <player> <rank>");
            $p = Core::getInstance()->getServer()->getPlayer($args[0]);
            $r = $args[1];
            $t = RankAPI::setRank($p, $r);
            if($t){
                $sender->sendMessage(Utils::getPrefix() . "Tu as bien mis le rank de §6{$p->getName()} §fsur §e$r");
                $p->sendMessage(Utils::getPrefix() . "Tu as reçu le rank §e$r");
            }else{
                $sender->sendMessage(Utils::getPrefix() . "Impossible de mettre le rank §e{$r}§f à §6{$p->getName()} §f, rank inexistant ou corrompu !");
            }
        }
    }
}