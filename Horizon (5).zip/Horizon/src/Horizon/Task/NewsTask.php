<?php

namespace Horizon\Task;

use Horizon\Core;
use Horizon\Utils\Utils;
use pocketmine\scheduler\Task;

class NewsTask extends Task{
    public $time = 1200;
    public function __construct(){}
    public function onRun(int $currentTick)
    {
        switch ($this->time){
            case 0:
                $this->time = 1201;
                Core::getInstance()->getServer()->broadcastMessage(Utils::getPrefix() . "Les grades te permettent d'obtenir des avantages in game, il sont ostensibles via la §eboutique");
                break;
            case 300:
                Core::getInstance()->getServer()->broadcastMessage(Utils::getPrefix() . "Personne suspecte d'utiliser quelconque cheat ? Report le nom avec le §e/report §fou sur notre §6discord §f!");
                break;
            case 600:
                Core::getInstance()->getServer()->broadcastMessage(Utils::getPrefix() . "Le §estaff §fest disponible pour toutes vos question !");
                break;
            case 900:
                Core::getInstance()->getServer()->broadcastMessage(Utils::getPrefix() . "Le server te plaît ? n'hésite pas à nous soutenir en votant !");
                break;
            case 1200:
                Core::getInstance()->getServer()->broadcastMessage(Utils::getPrefix() . "Tu veux avoir des récompenses ? Augmente ton grade en jeu (Rank : §6Bronze §fArgent §eOr §aEmeraude §5Epique)");
                break;
        }
        $this->time--;
    }
}