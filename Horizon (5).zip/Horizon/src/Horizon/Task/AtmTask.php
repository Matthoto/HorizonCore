<?php

namespace Horizon\Task;

use Horizon\Command\Joueur\AtmCommand;
use Horizon\Core;
use pocketmine\scheduler\Task;

class AtmTask extends Task{
    public $time = 60;
    public function __construct(){}
    public function onRun(int $currentTick)
    {
        $this->time--;
        if($this->time <= 0){
            foreach (Core::getInstance()->getServer()->getOnlinePlayers() as $p){
                if(AtmCommand::$atm->exists($p->getName())){
                    $m = AtmCommand::$atm->get($p->getName());
                    AtmCommand::$atm->set($p->getName(), $m + 1);
                    $p->sendPopup("§e§l» §f+1 dans l'atm");
                }else{
                    $p->sendPopup("§e§l» §fJe te conseil le /atm pour gagner des coins");
                }
            }
            $this->time = 60;
        }
    }
}