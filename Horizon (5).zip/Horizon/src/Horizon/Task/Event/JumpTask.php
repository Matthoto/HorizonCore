<?php

namespace Horizon\Task\Event;

use Horizon\API\CoinAPI;
use Horizon\Core;
use Horizon\Task\EventTask;
use Horizon\Utils\Utils;
use pocketmine\scheduler\Task;

class JumpTask extends Task{
    public $s = 0;
    public $min = 10;
    public static $pl = "off";
    public function __construct(){
    }
    public function onRun(int $currentTick)
    {
        if ($this->s <= 0) {
            if ($this->min > 0) {
                $this->s = 60;
                $this->min--;
            }
            switch ($this->min) {
                case 5:
                    Core::getInstance()->getServer()->broadcastMessage(Utils::EVENT . "Il reste 5 min avant la fin de l'event");
                    break;
                case 1:
                    Core::getInstance()->getServer()->broadcastMessage(Utils::EVENT . "Il reste 1 min avant la fin de l'event");
                    break;
                case 0:
                    Core::getInstance()->getServer()->broadcastMessage(Utils::EVENT . "L'event est fini il n'y a aucun gagnant");
                    if (count(Core::getInstance()->getServer()->getLevelByName("event")->getPlayers()) == 0) {
                        Core::getInstance()->getScheduler()->cancelTask($this->getTaskId());
                    } else {
                        foreach (Core::getInstance()->getServer()->getLevelByName("event")->getPlayers() as $p) {
                            $p->teleport(Core::getInstance()->getServer()->getDefaultLevel()->getSafeSpawn());
                            $p->sendMessage(Utils::EVENT . "Merci d'avoir participé à l'event");
                            CoinAPI::addMoney($p, 20);
                            Core::getInstance()->getScheduler()->cancelTask($this->getTaskId());
                        }
                    }
                    EventTask::$event = "rien";
                    break;
            }
        }
        if(self::$pl == "on") {
            if (Core::getInstance()->getServer()->getLevelByName("event")->getPlayers()) {
                foreach (Core::getInstance()->getServer()->getLevelByName("event")->getPlayers() as $p) {
                    $x = $p->getX();
                    $y = $p->getY();
                    $z = $p->getZ();
                    if ($x == 261 and $y == 17 and $z == 257) {
                        $p->sendMessage(Utils::EVENT . "GG, tu as gagné l'event voici ta récompense");
                        CoinAPI::addMoney($p, 250);
                        Core::getInstance()->getServer()->broadcastMessage(Utils::EVENT . "L'event est fini ! Le gagnant est §6{$p->getName()} §fGG à lui");
                        foreach (Core::getInstance()->getServer()->getLevelByName("event")->getPlayers() as $pl) {
                            $pl->teleport(Core::getInstance()->getServer()->getDefaultLevel()->getSafeSpawn());
                            $pl->sendMessage(Utils::EVENT . "Merci d'avoir participé à l'event, voici 20€");
                            CoinAPI::addMoney($pl, 20);
                            Core::getInstance()->getScheduler()->cancelTask($this->getTaskId());
                        }
                        EventTask::$event = "rien";
                    }
                }
            }
        }
    }
}