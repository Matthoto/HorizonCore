<?php

namespace Horizon\Task;

use Horizon\Core;
use Horizon\Task\Event\JumpTask;
use Horizon\Utils\Utils;
use pocketmine\scheduler\Task;

class EventTask extends Task{
    public static $min = 120;
    public static $s = 60;

    public static $event;
    public function __construct(){
    }
    public function onRun(int $currentTick)
    {
        self::$s--;
        if(self::$s <= 0){
            if(self::$min > 0) {
                self::$min--;
                self::$s = 60;
            }
            switch (self::$min) {
                case 10:
                    Core::getInstance()->getServer()->broadcastMessage(Utils::EVENT . "Event dans 10 minutes !");
                    break;
                case 1:
                    Core::getInstance()->getServer()->broadcastMessage(Utils::EVENT . "Event dans 1 minutes !");
                    break;
                case 0:
                    $r = random_int(1, 1);
                    self::$min = 130;
                    switch ($r) {
                        case 1:
                            Core::getInstance()->getServer()->broadcastMessage(Utils::EVENT . "Event jump ! Téléportez vous avec le /event");
                            Core::getInstance()->getScheduler()->scheduleRepeatingTask(new JumpTask(), 20);
                            self::$event = "jump";
                            break;
                    }
                    break;
            }
        }
    }
}