<?php

namespace Horizon\Task;

use Horizon\API\CoinAPI;
use Horizon\API\PassCombatAPI;
use Horizon\API\PointBoutiqueAPI;
use Horizon\API\RankAPI;
use Horizon\Core;
use pocketmine\network\mcpe\protocol\RemoveObjectivePacket;
use pocketmine\network\mcpe\protocol\SetDisplayObjectivePacket;
use pocketmine\network\mcpe\protocol\SetScorePacket;
use pocketmine\network\mcpe\protocol\types\ScorePacketEntry;
use pocketmine\Player;
use pocketmine\scheduler\Task;
use pocketmine\Server;

class ScoreboardTask extends Task{
    public function __construct() {}
    public function addScoreboard(Player $player, string $objectiveName, string $displayName) {
        $pack = new SetDisplayObjectivePacket();
        $pack->displaySlot = "sidebar";
        $pack->objectiveName = $objectiveName;
        $pack->displayName = $displayName;
        $pack->criteriaName = "dummy";
        $pack->sortOrder = 0;
        $player->dataPacket($pack);
    }

    public function setLine(Player $player, string $objectiveName, int $line, string $message) {
        $entry = new ScorePacketEntry();
        $entry->scoreboardId = $line;
        $entry->objectiveName = $objectiveName;
        $entry->score = $line;
        $entry->type = $entry::TYPE_FAKE_PLAYER;
        $entry->customName = $message;
        $pack = new SetScorePacket();
        $pack->type = $pack::TYPE_CHANGE;
        $pack->entries[] = $entry;
        $player->dataPacket($pack);
    }

    public function removeScoreboard(Player $player, string $objectiveName) {
        $pack = new RemoveObjectivePacket();
        $pack->objectiveName = $objectiveName;
        $player->dataPacket($pack);
    }

    public function onRun(int $currentTick) {
        foreach (Server::getInstance()->getOnlinePlayers() as $player) {
            $this->removeScoreboard($player, "Main");
            $this->addScoreboard($player, "Main", "§f--- [ §e§lHorizon §r§f] ---");
            $this->setLine($player, "Main", 0, "§7---------------------");
            $this->setLine($player, "Main", 1, "§l§e» Profile");
            $this->setLine($player, "Main", 2, "§7Grade: " . RankAPI::getRank($player));
            $this->setLine($player, "Main", 3, "§7Money: " . CoinAPI::getMoney($player));
            $this->setLine($player, "Main", 4, "§7Gemmes: " . PointBoutiqueAPI::getPB($player));
            $this->setLine($player, "Main", 5, "§7---------------------");
            $this->setLine($player, "Main", 6, "§l§e» Pass de combat");
            $this->setLine($player, "Main", 7, "§7Rank: " . PassCombatAPI::FormatPalier($player));
            $this->setLine($player, "Main", 8, "§7Xp: " . PassCombatAPI::ScoreBoardXP($player));
            $this->setLine($player, "Main", 9, "§7---------------------");
            $this->setLine($player, "Main", 10, "§l§e» Serveur");
            $this->setLine($player, "Main", 11, "§7Slot: " . count(Core::getInstance()->getServer()->getOnlinePlayers()) . "/" . Core::getInstance()->getServer()->getMaxPlayers());
            $this->setLine($player, "Main", 12, "§7Ping: " . $player->getPing() . " ms");
            $this->setLine($player, "Main", 13, "§f- [ §eip soon... §f] -");
        }
    }
}