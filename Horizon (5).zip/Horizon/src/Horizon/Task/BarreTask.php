<?php

namespace Horizon\Task;

use Horizon\API\PassCombatAPI;
use Horizon\Command\Joueur\AtmCommand;
use Horizon\Core;
use pocketmine\Player;
use pocketmine\scheduler\Task;

class BarreTask extends Task{
    public function __construct(){}
    public function onRun(int $currentTick)
    {
        foreach (Core::getInstance()->getServer()->getOnlinePlayers() as $p){
            $p->addActionBarMessage(PassCombatAPI::FormatPalier($p) . " §f| " . PassCombatAPI::ScoreBoardXP($p) . " §f| Atm: " . BarreTask::AtmAff($p));
        }
    }
    public static function AtmAff($p){
        $c = AtmCommand::$atm;
        if($c->exists($p->getName())){
            return $c->get($p->getName());
        }else{
            return "Non Démarrer";
        }
    }
}