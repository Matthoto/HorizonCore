<?php

namespace Horizon\Task;

use Horizon\Core;
use Horizon\Utils\Utils;
use pocketmine\Player;
use pocketmine\scheduler\Task;
use pocketmine\Server;

class ClearLagTask extends Task{
    public $time = 180;
    public function __construct(){}
    public function onRun(int $currentTick)
    {
        $this->time--;
        switch ($this->time){
            case 0:
                $entities = 0;
                foreach (Core::getInstance()->getServer()->getLevels() as $l){
                    foreach ($l->getEntities() as $entity){
                        if(!$entity instanceof Player) {
                            $entity->kill();
                            $entity++;
                        }
                    }
                }
                Server::getInstance()->broadcastMessage(Utils::CLEARLAG . "Le §eClearLagg §fa supprimé un totale de §6$entities §fentitées !");
                $this->time = 180;
                break;
            case 15:
                Core::getInstance()->getServer()->broadcastMessage(Utils::CLEARLAG . "Prochain §eClearLagg §fdans §615 seconde(s) §f!");
                break;
        }
    }
}