<?php

namespace Horizon\Utils;

use Horizon\Core;

class Utils{
    const PREFIX = "§eHorizon§l§6»§r§f ";
    const NOPERM = self::PREFIX . "§cTu n'as pas la permission de faire ceci";
    const SANC = "§eSanction§l§6»§r§f ";
    const CLEARLAG = "§eHorizonLagg§6§l»§r§f ";
    const LUCKY = "§eLuckyBlock§6§l»§r§f ";
    const EVENT = "§eEvent§6§l»§r§f ";
    public static function getPrefix(){
        return self::PREFIX;
    }
    public static function sendWebHook(string $a, string $b, string $c){
        Core::getInstance()->getLogger()->info("Salut bg");
    }
}