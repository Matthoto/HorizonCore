<?php

namespace Horizon\Utils;

use Horizon\Core;
use pocketmine\Player;

class BoutiqueForm{
    public static function Menu($player){
        $api = Core::getInstance()->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $p, int $data){
            $p->sendMessage(Utils::getPrefix() . "Boutique en développement");
            return true;
        });
        $form->setTitle("§e> §fBoutique §e<");
        $form->addButton("§c<- Retour");
        $form->addButton("§fFarmez des pb");
        $form->addButton("§fGrades");
        $form->addButton("§fBox");
        $form->addButton("§fParticule");
        $form->addButton("§f- Soon -");
        $form->sendToPlayer($player);
    }
}