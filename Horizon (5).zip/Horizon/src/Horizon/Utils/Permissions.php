<?php

namespace Horizon\Utils;

interface Permissions{
    const RANK = "admin";
    const KICK = "guide";
    const FREEZE = "modo";
    const BAN = "modo";
    const MUTE = "guide";
    const SETMONEY = "admin";
    const PASSCOMBAT = "admin";
    const EVENT = "admin";
    const STAFFMODE = "guide";
    const MODIF = "admin";

    const Vip = "vip";
    const VipPlus = "vip+";
    const Divin = "Divin";
    const Legende = "legende";
    const Lucky = "lucky";
}