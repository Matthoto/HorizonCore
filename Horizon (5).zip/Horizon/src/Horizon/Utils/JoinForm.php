<?php

namespace Horizon\Utils;

use Horizon\Core;
use pocketmine\Player;

class JoinForm{
    public static function Form($player){
        $api = Core::getInstance()->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $p, int $data = null){ return true; });
        $form->setTitle("§6§l» §eHorizon News");
        $form->setContent("§7Discord de Horizon : https://discord.gg/mHTeDMhKZ7 \n§7Boutique : (voir discord) \n\n§7Update : \n§7Serveur en dev");
        $form->addButton("» §aOK !");
        $form->sendToPlayer($player);
    }
    public static function NewForm($player){
        $api = Core::getInstance()->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $p, int $data = null){ return true; });
        $form->setTitle("§6§l» §fHorizon §eWelcome");
        $form->setContent("§fBienvenue pour la première fois sur §eHorizon §6Network§f, Bon jeu à toi sur le serveur !\n§7Discord de Horizon : https://discord.gg/mHTeDMhKZ7 \n§7Boutique : (voir discord) \n\n§7Update : \n§7Serveur en dev");
        $form->addButton("» §eCommencez à joué");
        $form->sendToPlayer($player);
    }
}