<?php

namespace Horizon\Event;

use Horizon\API\RankAPI;
use Horizon\Utils\Permissions;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\Listener;

class Protection implements Listener{
    public function onBreak(BlockBreakEvent $e){
        if(!RankAPI::hasPerm($e->getPlayer(), Permissions::MODIF)) {
            $e->setCancelled(true);
        }
    }
    public function onPlace(BlockPlaceEvent $e){
        if(!RankAPI::hasPerm($e->getPlayer(), Permissions::MODIF)) {
            $e->setCancelled(true);
        }
    }
    public function onDamage(EntityDamageEvent $e){
        $x = $e->getEntity()->getX();
        $z = $e->getEntity()->getZ();
        if(31 > $x and $x > -31 and 31 > $z and $z > -31){
            $e->setCancelled(true);
        }
    }
}