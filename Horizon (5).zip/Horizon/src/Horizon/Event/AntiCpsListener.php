<?php

namespace Horizon\Event;

use Horizon\Command\Staff\BanCommand;
use Horizon\Core;
use Horizon\Utils\Utils;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\Listener;
use pocketmine\Player;

class AntiCpsListener implements Listener{
    public static $cps = [];
    public function onDamage(EntityDamageEvent $e){
        if ($e instanceof EntityDamageByEntityEvent){
            $c = $e->getEntity()->getLastDamageCause();
            $p = $e->getEntity();
            if($c instanceof Player){
                if($p instanceof Player){
                    $t = time();
                    if(!isset(self::$cps[$c->getName()])) {
                        self::$cps[$c->getName()] = "{$t}:1";
                    }else{
                        $cps = explode(":", self::$cps[$c->getName()]);
                        if($cps[0] == time()){
                            $cp = (int) $cps[1] + 1;
                            self::$cps[$p->getName()] = "$t:$cp";
                            if($cp >= 22){
                                $c->kick("§f----- ] §eHorizon AntiCheat §f[ -----\n§fTu as été kick automatiquement car tu fais trop de CPS\nSi vous avez un cheat merci de le désactivé sinon vous serez bannis du serveur");
                                Core::getInstance()->getServer()->broadcastMessage(Utils::getPrefix() . "§6{$c->getName()} §fa été kick par §6AntiCheat §fpour: §eCPS Limite dépassé");
                            }
                        }else{
                            self::$cps[$p->getName()] = "$t:1";
                        }
                    }
                }
            }
        }
    }
}