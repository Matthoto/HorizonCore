<?php

namespace Horizon\Event;

use Horizon\API\CoinAPI;
use Horizon\Core;
use Horizon\Utils\Utils;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\Item;
use pocketmine\Player;

class InteractEvent implements Listener{
    public static $id = [];
    public static $prix = [];
    public function onInteract(PlayerInteractEvent $e){
        $p = $e->getPlayer();
        switch ($e->getBlock()->getId()){
            case Item::ANVIL:
                $e->setCancelled(true);
                if($e->getItem()->getDamage() == 0){
                    $e->getPlayer()->sendMessage(Utils::getPrefix() . "§cTu ne peux pas réparé cet item");
                }else {
                    $this->RepairForm($e->getPlayer());
                }
                break;
            case Item::ENCHANTING_TABLE:
                $e->setCancelled(true);
                $this->EnchantForm($p);
                break;
            case Item::CRAFTING_TABLE:
                $e->setCancelled(true);
                $p->sendMessage(Utils::getPrefix() . "§cLes crafting table sont désactivé");
                break;
        }
        switch ($e->getItem()->getId()){
            case Item::GHAST_TEAR:
                $p->getInventory()->setItemInHand($p->getInventory()->getItemInHand()->setCount($p->getInventory()->getItemInHand()->getCount() - 1));
                $p->addEffect(new EffectInstance(Effect::getEffect(Effect::STRENGTH), 120, 1));
                break;
            case Item::PRISMARINE_SHARD:
                $p->getInventory()->setItemInHand($p->getInventory()->getItemInHand()->setCount($p->getInventory()->getItemInHand()->getCount() - 1));
                $p->addEffect(new EffectInstance(Effect::getEffect(Effect::SPEED), 120, 1));
                break;
            case Item::COOKED_CHICKEN:
                $p->getInventory()->setItemInHand($p->getInventory()->getItemInHand()->setCount($p->getInventory()->getItemInHand()->getCount() - 1));
                $p->setHealth($p->getHealth() + 10);
                $e->setCancelled(true);
                break;
        }
    }
    public function RepairForm($player)
    {
        $api = Core::getInstance()->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $p, int $data = null){
            $r = $data;
            switch ($r){
                case 1:
                    if(CoinAPI::getMoney($p) >= 15) {
                        $i = $p->getInventory()->getItemInHand();
                        $p->getInventory()->setItemInHand($i->setDamage(0));
                        $p->sendMessage(Utils::getPrefix() . "Tu as bien réparé ton item");
                        CoinAPI::removeMoney($p, 15);
                    }else{
                        $p->sendMessage(Utils::getPrefix() . "§cTu n'as pas assez d'argent");
                    }
            }
        });
        $form->setTitle("§l§6» §r§eHorizon §fEnclume");
        $form->setContent("§fVeux tu repair ton item en main pour la somme de 10 coins ?");
        $form->addButton("§cNon");
        $form->addButton("§aOui");
        $form->sendToPlayer($player);
    }
    public function EnchantForm($player){
        $api = Core::getInstance()->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $p, int $data = null){
            $r = $data;
            switch ($r){
                case 1:
                    self::Level($p, 0, 10);
                    break;
                case 2:
                    self::Level($p, 17, 10);
                    break;
                case 3:
                    self::Level($p, 9, 10);
                    break;
            }
        });
        $form->setTitle("§l§6» §r§eHorizon §fTable d'Enchantement");
        $form->setContent("§fListe d'enchantement");
        $form->addButton("§c§l» Fermer");
        $form->addButton("§fProtection - 10€/level");
        $form->addButton("§fSolidité - 10€/level");
        $form->addButton("§fTranchant - 10€/level");
        $form->sendToPlayer($player);
    }
    public static function Level($player, int $enchantid, int $prix){
        self::$id[$player->getName()] = $enchantid;
        self::$prix[$player->getName()] = $prix;
        $api = Core::getInstance()->getServer()->getPluginManager()->getPlugin("FormAPI");
        $form = $api->createSimpleForm(function (Player $p, int $data = null){
            $r = $data;
            $i = $p->getInventory()->getItemInHand();
            $prix = self::$prix[$p->getName()] * $r;
            if($prix <= CoinAPI::getMoney($p)) {
                $p->sendMessage(Utils::getPrefix() . "Ton enchantment a bien réussi");
                CoinAPI::removeMoney($p, $prix);
                switch ($r) {
                    case 1:
                        $i->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(self::$id[$p->getName()]), 1));
                        $p->getInventory()->setItemInHand($i);
                        break;
                    case 2:
                        $i->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(self::$id[$p->getName()]), 2));
                        $p->getInventory()->setItemInHand($i);
                        break;
                    case 3:
                        $i->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(self::$id[$p->getName()]), 3));
                        $p->getInventory()->setItemInHand($i);
                        break;
                    case 4:
                        $i->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(self::$id[$p->getName()]), 4));
                        $p->getInventory()->setItemInHand($i);
                        break;
                }
            }else{
                $p->sendMessage(Utils::getPrefix() . "§cTu n'as pas assez d'argent");
            }
        });
        $form->setTitle("§6§l» §r§eHorizon §fTable d'Enchantement");
        $form->setContent("§fChoisi un niveau");
        $form->addButton("§c§l» Fermer");
        $form->addButton("§l» §r§eNiveau §61");
        $form->addButton("§l» §r§eNiveau §62");
        $form->addButton("§l» §r§eNiveau §63");
        $form->addButton("§l» §r§eNiveau §64");
        $form->sendToPlayer($player);
    }
}