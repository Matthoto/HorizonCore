<?php

namespace Horizon;

use Horizon\API\CoinAPI;
use Horizon\API\PassCombatAPI;
use Horizon\API\PointBoutiqueAPI;
use Horizon\API\RankAPI;
use Horizon\API\LuckyBlockAPI;
use Horizon\Command\Staff\BanCommand;
use Horizon\Command\Staff\FreezeCommand;
use Horizon\Command\Staff\MuteCommand;
use Horizon\Utils\JoinForm;
use Horizon\Utils\Permissions;
use Horizon\Utils\Utils;
use pocketmine\block\BlockIds;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\entity\ProjectileHitBlockEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerExhaustEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\item\Item;
use pocketmine\level\sound\EndermanTeleportSound;
use pocketmine\Player;

class EventListener implements Listener {
    public function onPlayerJoin(PlayerJoinEvent $event)
    {
        $sender = $event->getPlayer();
        $sender->teleport(Core::getInstance()->getServer()->getDefaultLevel()->getSafeSpawn());
        PointBoutiqueAPI::checkPlayer($sender);
        if (!$sender->hasPlayedBefore()) {
            RankAPI::setRank($sender, "Joueur");

            $event->setJoinMessage(" ");
            Core::getInstance()->getServer()->broadcastMessage(Utils::getPrefix() . "§6{$sender->getName()} §fest nouveau sur le serveur.");
            $nametag = "§bNew §l»§r" . RankAPI::getNametagPl($sender);
            JoinForm::NewForm($sender);

        } else {


            $event->setJoinMessage(" ");
            Core::getInstance()->getServer()->broadcastMessage("§7[§a+§7] {$sender->getName()}");
            $nametag = RankAPI::getNametagPl($sender);
            JoinForm::Form($sender);

        }
        $sender->setNameTag($nametag);

        if(FreezeCommand::$list->exists($sender->getName())){
            if(FreezeCommand::$list->get($sender->getName()) == "on"){
                $sender->setImmobile(true);
                $sender->sendMessage(Utils::getPrefix() . "Tu as été immobilisé par un staff");
            }
        }
        if(BanCommand::$list->exists($sender->getName())){
            $l = explode(":", BanCommand::$list->get($sender->getName()));
            if($l[1] > time() or $l[1] == "-1"){
                $sender->kick("§e----- [ §6Horizon-Sanction §e] ----- \n §eTu as été banni(e) par : §f{$l[0]} \n §ePendant encore : §f{$l[1]} jour(s) \n §e----- [ §6Horizon-Sanction §e] -----", false);
            }
        }
    }

    public function onPlayerQuit(PlayerQuitEvent $event) {

        $sender = $event->getPlayer();
        $event->setQuitMessage("§7[§c-§7] {$sender->getName()}");
    }

    public function playerchat(PlayerChatEvent $event) {
        $player = $event->getPlayer();
        
        $event->setFormat(RankAPI::getChatMsg($player, $event->getMessage()));
        
        $p = $event->getPlayer();
        $c = $event->getMessage();

        if(MuteCommand::$mute->exists($p->getName())){
            $l = explode(":", MuteCommand::$mute->get($p->getName()));
            if($l[0] > time()){
                $event->setCancelled(true);
                $t = $l[0] - time();
                $p->sendMessage(Utils::getPrefix() . "§cTu es encore mute pendant encore {$t} seconde(s) par {$l[1]} pour {$l[2]}");
                foreach (Core::getInstance()->getServer()->getOnlinePlayers() as $players){
                    if(RankAPI::hasPerm($players, Permissions::MUTE)){
                        $players->sendMessage(Utils::SANC . "§6{$p->getName()} §fa essayé de dire : §6$c");
                    }
                }
            }
        }

        $c = explode(" ", $c);
        foreach ($c as $w){
            switch ($w){
                case "Erodia":
                case "erodia":
                case "plutonium":
                case "TopBoy":
                case "topboy":
                    $p->sendMessage(Utils::getPrefix() . "§c§lNe fais pas de pub !");
                    $event->setCancelled(true);
                    break;
                case "admins":
                case "admin":
                case "modos":
                case "modo":
                    $p->sendMessage(Utils::getPrefix() . "§c§lPrécise ton problème et ne dit pas modo");
                    $event->setCancelled(true);
                    break;
            }
        }

    }
    public function onHit(ProjectileHitBlockEvent $e)
    {
        $entity = $e->getEntity();
        $name = (new \ReflectionClass($entity))->getShortName();
        if ("Egg" == $name) {
            $player = $entity->getOwningEntity();
            if ($player instanceof Player) {
                $player->teleport($e->getBlockHit());
                $player->getLevel()->addSound(new EndermanTeleportSound($player));
            }
        }
    }
    public function onDamage(EntityDamageEvent $e)
    {
        if ($e instanceof EntityDamageByEntityEvent) {
            $c = $e->getDamager();
            if($c instanceof Player){
                if($c->getInventory()->getItemInHand()->getId() == Item::BOW){
                    $e->setKnockBack(1);
                }else{
                    $e->setKnockBack(0.37);
                }
            }
        }
    }
    public function onKill(PlayerDeathEvent $event){
        $player = $event->getPlayer()->getName();
        $players = $event->getPlayer();
        $event->setDeathMessage("");

        $cause = $players->getLastDamageCause()->getCause();
        $i = Core::getInstance();
        if($cause === EntityDamageByEntityEvent::CAUSE_ENTITY_ATTACK){
            $kill = $players->getLastDamageCause()->getDamager();
            $killeur = $kill->getName();
            PassCombatAPI::addXp($kill, 10);
            PassCombatAPI::removeXp($players, 20);
            CoinAPI::addMoney($kill, 1);
            $random = mt_rand(1, 6);

            if($random === 1){
                $i->getServer()->broadcastMessage(Utils::getPrefix() . "§6{$killeur} §fhumilie §6{$player}");
            }
            if($random === 2){
                $i->getServer()->broadcastMessage(Utils::getPrefix() . "§6{$killeur} §fa tué §6{$player}");
            }
            if($random === 3){
                $i->getServer()->broadcastMessage(Utils::getPrefix() . "§6{$killeur} §fa explosé §6{$player}");
            }
            if($random === 4){
                $i->getServer()->broadcastMessage(Utils::getPrefix() . "§6{$killeur} §fa atomisé §6{$player}");
            }
            if($random === 5){
                $i->getServer()->broadcastMessage(Utils::getPrefix() . "§6{$player} §fa détruit §6{$player}");
            }
            if($random === 6){
                $i->getServer()->broadcastMessage(Utils::getPrefix() . "§6{$killeur} §fa défoncer §6{$player}");
            }

        }else{
            $i->getServer()->broadcastMessage(Utils::getPrefix() . "§6{$player} §fest mort");
        }
    }
    public function onBreak(BlockBreakEvent $e){
        if($e->getBlock()->getId() == BlockIds::SPONGE) {
            LuckyBlockAPI::RandomDrop($e->getPlayer());
            $e->getPlayer()->sendPopup(Utils::LUCKY . "Bonne chance !");
            $e->setDrops([]);
        }
    }
    public function AntiHunger(PlayerExhaustEvent $e){
        $e->setCancelled(true);
    }
}
