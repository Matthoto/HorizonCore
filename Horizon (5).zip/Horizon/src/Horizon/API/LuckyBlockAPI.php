<?php

namespace Horizon\API;

use Horizon\API\CoinAPI;
use Horizon\API\PassCombatAPI;
use Horizon\Command\Staff\BanCommand;
use Horizon\Core;
use Horizon\Utils\Utils;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\item\Item;
use pocketmine\Player;

class LuckyBlockAPI{
    public static function RandomDrop(Player $p){
        $r = random_int(0, 20);
        if(-1 < $r and $r < 3){
            $e = "§aL'argent c'est bien !";
            CoinAPI::addMoney($p, 500);
        }else if(2 < $r and $r < 5){
            $e = "§aVive les box(s)";
            Core::getInstance()->getServer()->dispatchCommand(new ConsoleCommandSender(), "key Commune 3 {$p->getName()}");
        }else if(4 < $r and $r < 7){
            $e = "§aUn peu d'xp";
            PassCombatAPI::addXp($p, 250);
        }else if($r == 7){
            $e = "§aQuel dinguerie";
            $i = Item::get(19, 0, 5);
            $i->setCustomName("§eLucky block");
            $p->getInventory()->addItem($i);
        }else if($r == 8){
            $e = "§aUpgrade de folie";
            PassCombatAPI::addXp($p, 750);
        }else if($r == 9){
            $e = "§aGapple en sueur";
            $i = Item::get(322, 0, 3);
            $p->getInventory()->addItem($i);
        }else if($r == 10){
            $e = "§aL'argent s'est encore mieux";
            CoinAPI::addMoney($p, 1000);
        }else{
            if(10 < $r and $r < 13){
                $e = "§cEmpoissoné";
                $p->addEffect(new EffectInstance(Effect::getEffect(Effect::POISON)));
            }else if(12 < $r and $r < 15){
                $e = "§cDégage";
                $p->kick("§e--- [ §fLuckyBlock §e] --- \n§f§lCHEH", false);
            }else if(14 < $r and $r < 17){
                $e = "§cLa boue";
                $i = Item::get(1, 0, 1);
                $i->setCustomName("§cBOUE");
                $p->getInventory()->addItem($i);
            }else if($r == 17){
                $e = "§cTu es un homme mort";
                $p->setHealth(1);
            }else if($r == 18){
                $e = "§cLa roue décide";
                $r = random_int(0, 26);
                $p->getInventory()->setItem($r, Item::get(0, 0, 0));
            }else if($r == 19){
                $e = "§cQuel moquerie";
                Core::getInstance()->getServer()->broadcastMessage(Utils::LUCKY . "§6§l{$p->getName()} §fs'est fait troll par un lucky block");
            }else if($r == 20){
                $e = "§cEspèce de cheater";
                $p->kick("§e--- [ §fLuckyBlock §cBAN §e] --- \n§f§lCHEH tu es ban 1 minutes", false);
                $t = time() + 60;
                BanCommand::$list->set("LuckyBlock:$t:§eLuckyBlock");
                BanCommand::$list->save();
            }
        }
        Core::getInstance()->getServer()->broadcastMessage(Utils::LUCKY . "§6{$p->getName()} §fa ouvert un §6LuckyBlock §fet a obtenu {$e}");
    }
}