<?php

namespace Horizon\API;

use Horizon\Core;
use pocketmine\Player;
use pocketmine\utils\Config;

class RankAPI
{
    public static $player;
    public static $permission;
    public static $nametag;
    public static $chat;
    public static function getRank(Player $p)
    {
        $c = self::$player;
        if ($c->exists($p->getName())) {
            return $c->get($p->getName());
        } else {
            return null;
        }
    }

    public static function hasPerm(Player $p, $permission)
    {
        $c = self::$permission;
        $rank = self::getRank($p);
        $a = 0;
        $pe = (array) $c->get($rank);
        foreach ($pe as $perm) {
            if($p->isOp()) $a = 1;
            if($perm == "*"){
                $a = 1;
            }else{
            	if ($permission == $perm) {
                	$a = 1;
            	} else {
                	if ($a == 0) {
                    	$a = 0;
                	}
            	}
            }
        }
        if ($a == 1){
            return true;
        }else{
            return false;
        }
    }

    public static function getChatMsg(Player $p, $msg){
        $pl = self::$player;
        $rank = $pl->get($p->getName());
        $c = self::$chat;
        $m = PassCombatAPI::FormatPalier($p) . " " . $c->get($rank);
        $m = str_replace("{player}", $p->getName(), $m);
        return str_replace("{msg}", $msg, $m);
    }
    public static function getNametagPl(Player $p){
        $rank = self::getRank($p);
        $c = self::$nametag;
        $r = PassCombatAPI::FormatPalier($p);
        $m = "$r \n". $c->get($rank);
        return str_replace("{player}", $p->getName(), $m);
    }
    public static function setRank(Player $p, $rank){
        $c = self::$player;
        $n = self::$nametag;
        if($n->exists($rank)) {
            $c->set($p->getName(), $rank);
        	$c->save();
            return true;
        }else{
            return false;
        }
    }
}