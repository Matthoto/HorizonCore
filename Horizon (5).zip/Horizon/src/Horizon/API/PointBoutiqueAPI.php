<?php

namespace Horizon\API;

use pocketmine\Player;
use pocketmine\utils\Config;

class PointBoutiqueAPI{
    /** @var Config */
    public static $db;
    public static function checkPlayer(Player $p){
        if(self::$db->exists($p->getName())){
            return true;
        }else{
            self::$db->set($p->getName());
            self::$db->save();
            return false;
        }
    }
    public static function getPB(Player $p){
        return self::$db->get($p->getName());
    }
    public static function addPB(Player $p, int $amount){
        self::$db->set($p->getName(), (int) self::$db->get($p->getName()) + $amount);
        self::$db->save();
    }
    public static function removePB(Player $p, int $amount){
        self::$db->set($p->getName(), (int) self::$db->get($p->getName()) - $amount);
    }
}