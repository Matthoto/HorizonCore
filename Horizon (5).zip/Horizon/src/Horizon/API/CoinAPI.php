<?php

namespace Horizon\API;

use pocketmine\Player;
use pocketmine\utils\Config;

class CoinAPI{
    /** @var Config */
    public static $money;
    public static function getMoney(Player $p){
        if(self::$money->exists($p->getName())){
            return self::$money->get($p->getName());
        }else{
            self::$money->set($p->getName(), 100);
            self::$money->save();
            return null;
        }
    }
    public static function setMoney(Player $p, int $amount){
        if($amount >= 0) {
            self::$money->set($p->getName(), $amount);
            self::$money->save();
        }
    }
    public static function addMoney(Player $p, int $amount){
        if($amount >= 0) {
            $a = self::getMoney($p);
            self::$money->set($p->getName(), $a + $amount);
            self::$money->save();
            return true;
        }else{
            return false;
        }
    }
    public static function removeMoney(Player $p, int $amount){
        if($amount >= 0) {
            $a = self::getMoney($p);
            self::$money->set($p->getName(), $a - $amount);
            self::$money->save();
            return true;
        }else{
            return false;
        }
    }
}