<?php

namespace Horizon\API;

use Horizon\Core;
use Horizon\Utils\Utils;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\Player;
use pocketmine\utils\Config;

class PassCombatAPI{
    /** @var Config */
    public static $xp;
    public static function getXp(Player $p){
        if(!self::$xp->exists($p->getName())) {
            self::$xp->set($p->getName(), "0:Bronze:0");
            self::$xp->save();
        }
        $xp = explode(":", self::$xp->get($p->getName()));
        return $xp[0];
    }
    public static function getPalier(Player $p){
        if(!self::$xp->exists($p->getName())) {
            self::$xp->set($p->getName(), "0:Bronze:0");
            self::$xp->save();
        }
        $xp = (array) explode(":", self::$xp->get($p->getName()));
        return [$xp[1], $xp[2]];
    }
    public static function FormatPalier(Player $p){
        $pa = self::getPalier($p);
        if($pa[0] == "Bronze" and $pa[1] == 0){
            return "§6Bronze";
        }else if($pa[0] == "Bronze" and $pa[1] == 1){
            return "§6Bronze I";
        }else if($pa[0] == "Bronze" and $pa[1] == 2){
            return "§6Bronze II";
        }else if($pa[0] == "Bronze" and $pa[1] == 3){
            return "§6Bronze III";
        }else {
            if ($pa[0] == "Argent" and $pa[1] == 0) {
                return "§7Argent";
            }else if($pa[0] == "Argent" and $pa[1] == 1){
                return "§7Argent I";
            }else if($pa[0] == "Argent" and $pa[1] == 2){
                return "§7Argent II";
            }else if($pa[0] == "Argent" and $pa[1] == 3){
                return "§7Argent III";
            }else{
                if ($pa[0] == "Or" and $pa[1] == 0) {
                    return "§eOr";
                }else if($pa[0] == "Or" and $pa[1] == 1){
                    return "§eOr I";
                }else if($pa[0] == "Or" and $pa[1] == 2){
                    return "§eOr II";
                }else if($pa[0] == "Or" and $pa[1] == 3){
                    return "§eOr III";
                }else{
                    if ($pa[0] == "Emeraude" and $pa[1] == 0) {
                        return "§aEmeraude";
                    }else if($pa[0] == "Emeraude" and $pa[1] == 1){
                        return "§aEmeraude I";
                    }else if($pa[0] == "Emeraude" and $pa[1] == 2){
                        return "§aEmeraude II";
                    }else if($pa[0] == "Emeraude" and $pa[1] == 3){
                        return "§aEmeraude III";
                    }else{
                        if ($pa[0] == "Epique" and $pa[1] == 0) {
                            return "§5Epique";
                        }else if($pa[0] == "Epique" and $pa[1] == 1){
                            return "§5Epique I";
                        }else if($pa[0] == "Epique" and $pa[1] == 2){
                            return "§5Epique II";
                        }else if($pa[0] == "Epique" and $pa[1] == 3){
                            return "§5Epique III";
                        }else{
                            if ($pa[0] == "Diamant" and $pa[1] == 0) {
                                return "§bDiamant";
                            }else if($pa[0] == "Diamant" and $pa[1] == 1){
                                return "§bDiamant I";
                            }else if($pa[0] == "Diamant" and $pa[1] == 2){
                                return "§bDiamant II";
                            }else if($pa[0] == "Diamant" and $pa[1] == 3){
                                return "§bDiamant III";
                            }
                        }
                    }
                }
            }
        }
    }
    public static function ScoreBoardXP(Player $p){
        $r = self::getPalier($p);
        $xp = self::getXp($p);
        $a = 0;
        if($r[0] == "Bronze") {
            $a = "{$xp}/100";
        }else if($r[0] == "Argent"){
            $a = "{$xp}/200";
        }else if($r[0] == "Or"){
            $a = "{$xp}/300";
        }else if($r[0] == "Diamant"){
            $a = "{$xp}/400";
        }else if($r[0] == "Emeraude"){
            $a = "{$xp}/500";
        }else if($r[0] == "Epique"){
            $a = "{$xp}/750";
        }
        return $a;
    }

    public static function addXp(Player $p, int $amount){
        $r = self::getPalier($p);
        $at = (int) self::getXp($p);
        $xp = $at + $amount;
        self::$xp->set($p->getName(), "$xp:{$r[0]}:{$r[1]}");
        $p->sendPopup("§e> §f+{$amount} xp §e<");
        if($r[0] == "Bronze"){
            if($xp >= 100){
                if($r[1] == 0) {
                    Core::getInstance()->getServer()->broadcastMessage(Utils::getPrefix() . "§6{$p->getName()} §fviens de passer §6Bronze I");
                    self::getPalier($p);
                    self::$xp->set($p->getName(), "0:Bronze:1");
                    CoinAPI::addMoney($p, 5);
                }else if($r[1] == 1){
                    Core::getInstance()->getServer()->broadcastMessage(Utils::getPrefix() . "§6{$p->getName()} §fviens de passer §6Bronze II");
                    self::getPalier($p);
                    self::$xp->set($p->getName(),"0:Bronze:2");
                    CoinAPI::addMoney($p, 7);
                }else if($r[1] == 2){
                    Core::getInstance()->getServer()->broadcastMessage(Utils::getPrefix() . "§6{$p->getName()} §fviens de passer §6Bronze III");
                    self::$xp->set($p->getName(), "0:Bronze:3");
                    Core::getInstance()->getServer()->dispatchCommand(new ConsoleCommandSender(), "key Vote 2 {$p->getName()}");
                }else if($r[1] == 3){
                    Core::getInstance()->getServer()->broadcastMessage(Utils::getPrefix() . "§6{$p->getName()} §fviens de passer §7Argent 0");
                    self::$xp->set($p->getName(), "0:Argent:0");
                }
            }
        }
        if($r[0] == "Argent"){
            if($xp >= 200){
                if($r[1] == 0) {
                    Core::getInstance()->getServer()->broadcastMessage(Utils::getPrefix() . "§6{$p->getName()} §fviens de passer §7Argent I");
                    self::$xp->set($p->getName(), "0:Argent:1");
                    CoinAPI::addMoney($p, 9);
                }else if($r[1] == 1){
                    Core::getInstance()->getServer()->broadcastMessage(Utils::getPrefix() . "§6{$p->getName()} §fviens de passer §7Argent II");
                    self::$xp->set($p->getName(), "0:Argent:2");
                    Core::getInstance()->getServer()->dispatchCommand(new ConsoleCommandSender(), "key Vote 2 {$p->getName()}");
                }else if($r[1] == 2){
                    Core::getInstance()->getServer()->broadcastMessage(Utils::getPrefix() . "§6{$p->getName()} §fviens de passer §7Argent III");
                    self::$xp->set($p->getName(), "0:Argent:3");
                    CoinAPI::addMoney($p, 11);
                }else if($r[1] == 3){
                    Core::getInstance()->getServer()->broadcastMessage(Utils::getPrefix() . "§6{$p->getName()} §fviens de passer §eOr 0");
                    self::getPalier($p);
                    self::$xp->set($p->getName(), "0:Or:0");
                }
            }
        }
        if($r[0] == "Or"){
            if($xp >= 300){
                if($r[1] == 0) {
                    Core::getInstance()->getServer()->broadcastMessage(Utils::getPrefix() . "§6{$p->getName()} §fviens de passer §eOr I");
                    self::$xp->set($p->getName(), "0:Or:1");
                    CoinAPI::addMoney($p, 15);
                }else if($r[1] == 1){
                    Core::getInstance()->getServer()->broadcastMessage(Utils::getPrefix() . "§6{$p->getName()} §fviens de passer §eOr II");
                    self::$xp->set($p->getName(), "0:Or:2");
                    Core::getInstance()->getServer()->dispatchCommand(new ConsoleCommandSender(), "key Epique 1 {$p->getName()}");
                }else if($r[1] == 2){
                    Core::getInstance()->getServer()->broadcastMessage(Utils::getPrefix() . "§6{$p->getName()} §fviens de passer §eOr III");
                    self::$xp->set($p->getName(), "0:Or:3");
                    CoinAPI::addMoney($p, 20);
                }else if($r[1] == 3){
                    Core::getInstance()->getServer()->broadcastMessage(Utils::getPrefix() . "§6{$p->getName()} §fviens de passer §bDiamant 0");
                    self::getPalier($p);
                    self::$xp->set($p->getName(), "0:Diamant:0");
                }
            }
        }
        if($r[0] == "Diamant"){
            if($xp >= 400){
                if($r[1] == 0) {
                    Core::getInstance()->getServer()->broadcastMessage(Utils::getPrefix() . "§6{$p->getName()} §fviens de passer §bDiamant I");
                    self::getPalier($p);
                    self::$xp->set($p->getName(), "0:Diamant:1");
                    CoinAPI::addMoney($p, 25);
                }else if($r[1] == 1){
                    Core::getInstance()->getServer()->broadcastMessage(Utils::getPrefix() . "§6{$p->getName()} §fviens de passer §bDiamant II");
                    self::getPalier($p);
                    self::$xp->set($p->getName(), "0:Diamant:2");
                    Core::getInstance()->getServer()->dispatchCommand(new ConsoleCommandSender(), "key Epique 2 {$p->getName()}");
                }else if($r[1] == 2){
                    Core::getInstance()->getServer()->broadcastMessage(Utils::getPrefix() . "§6{$p->getName()} §fviens de passer §bDiamant III");
                    self::$xp->set($p->getName(), "0:Diamant:3");
                    CoinAPI::addMoney($p, 30);
                }else if($r[1] == 3){
                    Core::getInstance()->getServer()->broadcastMessage(Utils::getPrefix() . "§6{$p->getName()} §fviens de passer §aEmeraude 0");
                    self::getPalier($p);
                    self::$xp->set($p->getName(), "0:Emeraude:0");
                }
            }
        }
        if($r[0] == "Emeraude"){
            if($xp >= 500){
                if($r[1] == 0) {
                    Core::getInstance()->getServer()->broadcastMessage(Utils::getPrefix() . "§6{$p->getName()} §fviens de passer §aEmeraude I");
                    self::$xp->set($p->getName(), "0:Emeraude:1");
                    CoinAPI::addMoney($p, 35);
                }else if($r[1] == 1){
                    Core::getInstance()->getServer()->broadcastMessage(Utils::getPrefix() . "§6{$p->getName()} §fviens de passer §aEmeraude II");
                    self::$xp->set($p->getName(), "0:Emeraude:2");
                    Core::getInstance()->getServer()->dispatchCommand(new ConsoleCommandSender(), "key Epique 3 {$p->getName()}");
                }else if($r[1] == 2){
                    Core::getInstance()->getServer()->broadcastMessage(Utils::getPrefix() . "§6{$p->getName()} §fviens de passer §aEmeraude III");
                    self::$xp->set($p->getName(), "0:Emeraude:3");
                    CoinAPI::addMoney($p, 40);
                }else if($r[1] == 3){
                    Core::getInstance()->getServer()->broadcastMessage(Utils::getPrefix() . "§6{$p->getName()} §fviens de passer §5Epique 0");
                    self::$xp->set($p->getName(), "0:Epique:0");
                }
            }
        }
        if($r[0] == "Epique"){
            if($xp >= 750){
                if($r[1] == 0) {
                    Core::getInstance()->getServer()->broadcastMessage(Utils::getPrefix() . "§6{$p->getName()} §fviens de passer §5Epique I");
                    self::$xp->set($p->getName(), "0:Epique:1");
                    Core::getInstance()->getServer()->dispatchCommand(new ConsoleCommandSender(), "key Epique 4 {$p->getName()}");
                }else if($r[1] == 1){
                    Core::getInstance()->getServer()->broadcastMessage(Utils::getPrefix() . "§6{$p->getName()} §fviens de passer §5Epique II");
                    self::$xp->set($p->getName(), "0:Epique:2");
                    Core::getInstance()->getServer()->dispatchCommand(new ConsoleCommandSender(), "key Horizon 1 {$p->getName()}");
                }else if($r[1] == 2){
                    Core::getInstance()->getServer()->broadcastMessage(Utils::getPrefix() . "§6{$p->getName()} §fviens de passer §5Epique III");
                    self::$xp->set($p->getName(), "0:Epique:3");
                    Core::getInstance()->getServer()->dispatchCommand(new ConsoleCommandSender(), "key Epique 5 {$p->getName()}");
                    Core::getInstance()->getServer()->dispatchCommand(new ConsoleCommandSender(), "key Horizone 2 {$p->getName()}");
                }else $p->sendMessage(Utils::getPrefix() . "Tu as déjà le maximum d'xp");
            }
        }
        self::$xp->save();
    }
    public static function removeXp(Player $p, $amount){
        if(!self::$xp->exists($p->getName())){
            self::$xp->set($p->getName(), "0:Bronze:0");
        }
        if(self::getXp($p) == 0){
            return false;
        }else {
            $r = self::getPalier($p);
            self::$xp->set($p->getName(), (self::getXp($p) - $amount) . ":" . $r[0] . ":" . $r[1]);
            self::$xp->save();
            return true;
        }
    }
}