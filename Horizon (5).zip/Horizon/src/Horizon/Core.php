<?php

namespace Horizon;

use Horizon\API\BoxAPI;
use Horizon\API\CoinAPI;
use Horizon\API\PassCombatAPI;
use Horizon\API\PointBoutiqueAPI;
use Horizon\API\RankAPI;
use Horizon\Command\Admin\GivePCCommand;
use Horizon\Command\Admin\SetRankCommand;
use Horizon\Command\Grade\BoutiqueCommand;
use Horizon\Command\Grade\LuckyPass;
use Horizon\Command\Grade\MyPbCommand;
use Horizon\Command\Grade\PayPbCommand;
use Horizon\Command\Grade\SeePbCommand;
use Horizon\Command\Joueur\AtmCommand;
use Horizon\Command\Joueur\EventCommand;
use Horizon\Command\Joueur\KitCommand;
use Horizon\Command\Joueur\MoneyCommand;
use Horizon\Command\Joueur\PassDeCombatCommand;
use Horizon\Command\Joueur\PayCommand;
use Horizon\Command\Admin\SetMoneyCommand;
use Horizon\Command\Joueur\ShopCommand;
use Horizon\Command\Joueur\SpawnCommand;
use Horizon\Command\Staff\BanCommand;
use Horizon\Command\Staff\FreezeCommand;
use Horizon\Command\Staff\KickCommand;
use Horizon\Command\Staff\MuteCommand;
use Horizon\Command\Staff\UnBanCommand;
use Horizon\Event\AntiCpsListener;
use Horizon\Event\InteractEvent;
use Horizon\Event\Protection;
use Horizon\Task\AtmTask;
use Horizon\Task\BarreTask;
use Horizon\Task\ClearLagTask;
use Horizon\Task\EventTask;
use Horizon\Task\NewsTask;
use Horizon\Task\ScoreboardTask;
use Horizon\Utils\BoutiqueForm;
use MongoDB\Driver\Command;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;

class Core extends PluginBase{
    public static $core;
    public function onEnable()
    {
        $this->getServer()->getPluginManager()->registerEvents(new EventListener(), $this);
        $this->getServer()->getPluginManager()->registerEvents(new InteractEvent(), $this);
        $this->getServer()->getPluginManager()->registerEvents(new AntiCpsListener(), $this);
        $this->getServer()->getPluginManager()->registerEvents(new Protection(), $this);

        $this->getScheduler()->scheduleRepeatingTask(new ScoreboardTask(), 30);
        $this->getScheduler()->scheduleRepeatingTask(new NewsTask(), 20);
        $this->getScheduler()->scheduleRepeatingTask(new ClearLagTask(), 20);
        self::$core = $this;
        $this->initCommands();
        $this->getServer()->getCommandMap()->registerAll("Horizon", [
            new SetrankCommand(),
            new GivePCCommand(),
            new SetMoneyCommand(),

            new BanCommand(),
            new FreezeCommand(),
            new KickCommand(),
            new MuteCommand(),
            new UnBanCommand(),

            new SpawnCommand(),
            new KitCommand(),
            new MoneyCommand(),
            new PayCommand(),
            new AtmCommand(),
            new KitCommand(),
            new PassDeCombatCommand(),
            new EventCommand(),
            new ShopCommand(),

            new LuckyPass(),
            new MyPbCommand(),
            new SeePbCommand(),
            new PayPbCommand(),
            new BoutiqueCommand(),
        ]);
        RankAPI::$player = new Config("Player.yml", Config::YAML);
        RankAPI::$permission = new Config("Permission.yml", Config::YAML);
        RankAPI::$nametag = new Config("Nametag.yml", Config::YAML);
        RankAPI::$chat = new Config("Chat.yml", Config::YAML);

        CoinAPI::$money = new Config("Money.yml", Config::YAML);

        PointBoutiqueAPI::$db = new Config("Pointboutique.yml", Config::YAML);

        PassCombatAPI::$xp = new Config("Passcombat.yml", Config::YAML);

        FreezeCommand::$list = new Config("freezelist.yml", Config::YAML);
        BanCommand::$list = new Config("Banlist.yml", Config::YAML);
        MuteCommand::$mute = new Config("Mutelist.yml", Config::YAML);
        LuckyPass::$list = new Config("Luckypass.yml", Config::YAML);
    }
    public static function getInstance() : Core {
        return self::$core;
    }
    private function initCommands() : void
    {
        $cmds = ["kick", "ban", "pardon"];
        $commands = $this->getServer()->getCommandMap();

        foreach ($cmds as $cmd) {
            $command = $commands->getCommand($cmd);
            if ($command !== null) {
                $command->setLabel("old_" . $cmd);
                $commands->unregister($command);
            }
        }
    }
}